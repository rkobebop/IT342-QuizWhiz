package cit.edu.quizwhiz.service;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.UserRecord;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FirebaseUserDetailsService implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String uid) throws UsernameNotFoundException {
        try {
            UserRecord userRecord = FirebaseAuth.getInstance().getUser(uid);
            return new org.springframework.security.core.userdetails.User(
                    userRecord.getEmail(),
                    "", // Firebase doesn’t expose password hashes
                    List.of() // Authorities can be customized
            );
        } catch (FirebaseAuthException e) {
            throw new UsernameNotFoundException("User not found");
        }
    }
}

